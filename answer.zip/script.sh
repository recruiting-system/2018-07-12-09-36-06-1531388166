#!/usr/bin/env bash

./gradlew clean test